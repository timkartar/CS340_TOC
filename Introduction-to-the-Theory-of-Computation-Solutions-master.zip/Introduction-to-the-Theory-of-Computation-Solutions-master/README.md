Introduction-to-the-Theory-of-Computation-Solutions
===================================================

If you want to contribute to this repository, feel free to create a pull request (please copy the format as in the other exercises). Also, let me know if there are any errors in the existing solutions.

Solutions to Michael Sipser's Introduction to the Theory of Computation Book (3rd Edition).

Completed chapters:
- Chapter 1: Not yet
- Chapter 2: Not yet
- Chapter 3: Not yet
- Chapter 4: Not yet
- Chapter 5: Not yet
- Chapter 6: Not yet
- Chapter 7: Not yet
- Chapter 8: Not yet
- Chapter 9: Not yet
- Chapter 10: Not yet
